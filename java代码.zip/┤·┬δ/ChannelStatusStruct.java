package com.zgyw.recordbox.struct;

import com.sun.jna.Pointer;
import com.sun.jna.Structure;

import java.util.Arrays;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: MR
 * @Date: 2021/11/12/16:05
 * @Description:
 */
public class ChannelStatusStruct extends Structure {

    public ChannelStatusStruct(Pointer pointer) {
        super(pointer);
        read();
    }

    /**
     * 电话状态
     */
    public byte PhoneStatus;
    /**
     * 响铃次数
     */
    public byte RingCount;
    /**
     * 是否启动或不启动
     */
    public byte PlayBackEnabled;
    /**
     * 电话号码长度
     */
    public byte PhoneNumLength;

    public byte[] PhoneNum = new byte[20];


    @Override
    protected List getFieldOrder() {
        return Arrays.asList(new String[] {
                "PhoneStatus",
                "RingCount",
                "PlayBackEnabled",
                "PhoneNumLength",
                "PhoneNum"
        });
    }
}
