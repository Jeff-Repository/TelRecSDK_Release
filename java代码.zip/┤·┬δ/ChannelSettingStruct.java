package com.zgyw.recordbox.struct;

import com.sun.jna.Pointer;
import com.sun.jna.Structure;

import java.util.Arrays;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: MR
 * @Date: 2021/11/12/18:56
 * @Description:
 */
public class ChannelSettingStruct extends Structure {

    public ChannelSettingStruct(Pointer pointer) {
        super(pointer);
        read();
    }

    public AutoReplyStruct[] AutoReply = new AutoReplyStruct[7];
    public byte EnableLostWarning;
    public byte EnableAnnouncement;
    public byte SaveAnnouncementToRecord;
    public byte RecordCondition;
    public byte EnableAutoReply;
    public byte SaveAutoReplyToRecord;
    public byte AutoReplyRingCount;
    public byte LeaveWordMaxTime;
    public byte LostVoltage;
    public byte OnHookVoltage;
    public byte OffHookVoltage;
    public byte RingVoltage;
    public byte[] ChannelName = new byte[28];
    public byte[] AnnouncementFileName = new byte[28];
    public byte[] Reserved = new byte[16];

    @Override
    protected List getFieldOrder() {
        return Arrays.asList(new String[] {
                "AutoReply",
                "EnableLostWarning",
                "EnableAnnouncement",
                "SaveAnnouncementToRecord",
                "RecordCondition",
                "EnableAutoReply",
                "SaveAutoReplyToRecord",
                "AutoReplyRingCount",
                "LeaveWordMaxTime",
                "LostVoltage",
                "OnHookVoltage",
                "OffHookVoltage",
                "RingVoltage",
                "ChannelName",
                "AnnouncementFileName",
                "Reserved",
        });
    }
}
