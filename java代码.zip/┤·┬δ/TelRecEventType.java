package com.zgyw.recordbox.enumeration;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: MR
 * @Date: 2021/11/12/15:40
 * @Description:
 */
public enum TelRecEventType {

    UpdateProgress,
    FoundDevice,
    GotDataSize,
    GotData,
    ConnectStatusChanged,
    StorageStatusChanged,
    CloudServerStatusChanged,
    OnlineUserListChanged,
    ChannelStatusChanged,
    ChannelTalkTimeChanged,
    ChannelMonitorChanged,
    ChannelPlayBackChanged,
    ChannelRecordEnd
}
