package com.zgyw.workorder.service.impl;
import com.sun.jna.Pointer;
import com.zgyw.recordbox.entity.TelRecFoundDevice;
import com.zgyw.recordbox.struct.TelRecFoundDeviceStructure;
import com.zgyw.workorder.domain.TelChannelConfig;
import com.zgyw.workorder.mapper.TelChannelConfigMapper;
import com.zgyw.workorder.service.SearchDeviceCallBack;
import com.zgyw.workorder.service.TelSDK;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

@Service
public class SearchDeviceCallBackImpl implements SearchDeviceCallBack{



//	static TelRec_FoundDeviceInfo DeviceInfo;

	public final int DeviceID_Length = 20;
	@Autowired
	private TelChannelConfigMapper telChannelConfigMapper;

    @Override
	public void SearchDeviceCallBack(int event, long device, Pointer data, int lenth) throws Exception {
   	  if(null != data){
		  System.out.println("--------------------成功搜索到设--------------------");
		  Long devices = 0L;
		  TelRecFoundDeviceStructure reference = new TelRecFoundDeviceStructure(data);
		  System.out.println("ID："+new String(reference.DeviceID,"utf-8")+"\n");
		  System.out.println("通道："+reference.Channels+"\n");
		  System.out.println("model："+reference.Model+"\n");
		  System.out.println("ip："+new String(reference.IPaddress,"utf-8")+"\n");
		  System.out.println("端口："+reference.NetPort+"\n");
		  System.out.println("版本："+new String(reference.Version,"utf-8")+"\n");

		  TelRecFoundDevice telRecFoundDevice = new TelRecFoundDevice();
		  telRecFoundDevice.setDeviceID(new String(reference.DeviceID,"utf-8"));
		  telRecFoundDevice.setChannels(reference.Channels);
		  telRecFoundDevice.setIPaddress(new String(reference.IPaddress,"utf-8"));
		  telRecFoundDevice.setNetPort(reference.NetPort);
		  telRecFoundDevice.setVersion(new String(reference.Version,"utf-8"));

//		  if(device != 0)
//		  {
//			  TelSDK.instance.TelRecAPI_Logout(devices);
//			  TelSDK.instance.TelRecAPI_DeleteDevice(devices);
//		  }
//		  //退出
//		  TelSDK.instance.TelRecAPI_Exit();
   	  }else{
		  System.out.println("-------------------嘤嘤嘤，搜索设备失败了呢~-------------------");
	  }

  }

	public Long createDevice(String DeviceID) {
		byte[] DeviceIDBytes = DeviceID.getBytes();
		if (DeviceIDBytes.length != DeviceID_Length){
			return 0L;
		}
		return TelSDK.instance.TelRecAPI_CreateDevice(DeviceIDBytes);
	}

	private static int convertByteToInt(byte data) {
		int heightBit = (int) ((data >> 4) & 0x0F);

		int lowBit = (int) (0x0F & data);

		return heightBit * 16 + lowBit;

	}

	@PostConstruct
	public void init(){

		SearchDeviceCallBackImpl searchDeviceCallBack = this;
		searchDeviceCallBack.telChannelConfigMapper = this.telChannelConfigMapper;
		int ret = TelSDK.instance.TelRecAPI_Init();

//		TelSDK.instance.TelRecAPI_C_Sea rchDevice(searchDeviceCallBack);
		for (TelChannelConfig item:searchDeviceCallBack.telChannelConfigMapper.selectTelChannelConfigList(new TelChannelConfig())) {
			Long devices = 0L;
			String username = item.getExtend().split(":")[0];
			String password = item.getExtend().split(":")[1]+"\0";
			devices = createDevice(item.getDevice());
			System.out.println("设备编号："+item.getDevice());
			System.out.println("地址："+item.getTel());
			System.out.println("端口："+item.getChannel());
			System.out.println("devices:"+devices);
			for (int i = item.getTel().length();i < 16;){
				i++;
				item.setTel(item.getTel()+"\0");
			}
			TelSDK.instance.TelRecAPI_SetNetAddr(devices,item.getTel().getBytes() ,Integer.valueOf(item.getChannel()));
			TelSDK.instance.TelRecAPI_SetUserPassword(devices,username.getBytes(),username.getBytes().length,password.getBytes());
			int status = TelSDK.instance.TelRecAPI_Login(devices,false);
			System.out.println("登录返回的状态码："+status);
			if( status == 0){
				System.out.println("登录成功");
				int channels = TelSDK.instance.TelRecAPI_DeviceChannels(devices);
				System.out.println("channels：-------------"+channels);
				//登录后同步缓存
				for (int i = 0;i<channels;i++) {
					TelSDK.instance.TelRecAPI_GetChannelSetting(devices,i);
				}

				TelSDK.instance.TelRecAPI_C_CreateHeartbeatThread(devices,HeartbeatCallBackImpl.instance );

			}else{
				System.out.println("登录失败");
			}
		}
    }
}
