package com.zgyw.recordbox.struct;

import com.sun.jna.Pointer;
import com.sun.jna.Structure;

import java.util.Arrays;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: MR
 * @Date: 2021/11/12/18:57
 * @Description:
 */
public class AutoReplyStruct extends Structure {
    public AutoReplyStruct(Pointer pointer) {
        super(pointer);
        read();
    }

    public ReplyTimeSlotStruct[] ReplyTimeSlot = new ReplyTimeSlotStruct[3];
    public byte AllDayLongReply;
    public byte[] FileName = new byte[28];

    @Override
    protected List getFieldOrder() {
        return Arrays.asList(new String[]{
                "ReplyTimeSlot",
                "AllDayLongReply",
                "FileName"
        });
    }
}
