package com.zgyw.recordbox.struct;

import com.sun.jna.Pointer;
import com.sun.jna.Structure;

import java.util.Arrays;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: MR
 * @Date: 2021/11/12/18:58
 * @Description:
 */
public class ReplyTimeSlotStruct extends Structure {

    public ReplyTimeSlotStruct(Pointer pointer) {
        super(pointer);
        read();
    }

    public byte Enable;
    public byte StartHour;
    public byte StartMinute;
    public byte EndHour;
    public byte EndMinute;
    public byte[] FileName = new byte[28];

    @Override
    protected List getFieldOrder() {
        return Arrays.asList(new String[] {
                "Enable",
                "StartHour",
                "StartMinute",
                "EndHour",
                "EndMinute",
                "FileName"
        });
    }
}
