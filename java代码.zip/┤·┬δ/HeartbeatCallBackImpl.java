package com.zgyw.workorder.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.sun.jna.Pointer;
import com.zgyw.common.core.domain.entity.SysDeptTel;
import com.zgyw.common.utils.URLUtils;
import com.zgyw.common.utils.spring.SpringUtils;
import com.zgyw.common.utils.uuid.UUID;
import com.zgyw.framework.manager.AsyncManager;
import com.zgyw.framework.websocket.WebSocketUsers;
import com.zgyw.recordbox.enumeration.PhoneStatusType;
import com.zgyw.recordbox.enumeration.TelRecEventType;
import com.zgyw.recordbox.struct.ChannelSettingStruct;
import com.zgyw.recordbox.struct.ChannelStatusStruct;
import com.zgyw.recordbox.struct.CurrentRecordInfoStruct;
import com.zgyw.system.service.ISysDeptTelService;
import com.zgyw.system.service.ISysUserService;
import com.zgyw.workorder.domain.Calllogtable;
import com.zgyw.workorder.domain.OrRecord;
import com.zgyw.workorder.service.*;
import com.zgyw.workorder.thread.DownloadFactory;
import it.sauronsoftware.jave.AudioAttributes;
import it.sauronsoftware.jave.Encoder;
import it.sauronsoftware.jave.EncodingAttributes;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: MR
 * @Date: 2021/11/12/17:59
 * @Description:
 */

public  class  HeartbeatCallBackImpl implements  HeartbeatCallBack{

    public static HeartbeatCallBackImpl instance = new HeartbeatCallBackImpl();

    //来电时一个号码只需创建一次通话记录
    static ConcurrentHashMap<String,Integer> map = new ConcurrentHashMap<>();

    //来电时一个号码可以拥有一个uuid，结束录音后通过号码找到uuid修改录音文件地址 并删除该数据
    public static ConcurrentHashMap<String,String> mapUUid = new ConcurrentHashMap<>();


    static ConcurrentHashMap<String,Long> recordMap = new ConcurrentHashMap<>();







    @Override
    public int HeartbeatCallBack(int event, Long EventDevice, Long data, int Length)throws Exception {

        int channel;
        channel = data.intValue();
        TelRecEventType telRecEventType = TelRecEventType.values()[event];
        ICalllogtableService calllogtableService  = SpringUtils.getBean(ICalllogtableService.class);

        Pointer pointer = TelSDK.instance.TelRecAPI_ChannelSetting(EventDevice,channel);

        ChannelSettingStruct channelSettingStruct = new ChannelSettingStruct(pointer);
        //获取通道名称
        String phone = new String(channelSettingStruct.ChannelName,"utf-8");

        switch (telRecEventType){
            case ConnectStatusChanged:
            case StorageStatusChanged:
            case CloudServerStatusChanged:
            case OnlineUserListChanged:

                break;
            case ChannelStatusChanged:
            {

                System.out.println("通道ID："+channel);

                Pointer channelStatus = TelSDK.instance.TelRecAPI_ChannelStatus(EventDevice, channel);

                ChannelStatusStruct channelStatusStruct = new ChannelStatusStruct(channelStatus);


                //获取来电电话
                channelStatusStruct.PhoneNum[channelStatusStruct.PhoneNumLength] = '\0';//
                String  callPhone = new String(channelStatusStruct.PhoneNum,"utf-8");

                if(convertByteToInt(channelStatusStruct.PhoneStatus) <  PhoneStatusType.PhoneStatusTypeMax.ordinal()){

//                    TelRecChannelStatus telRecChannelStatus = new TelRecChannelStatus();
//                    telRecChannelStatus.setPhoneNum(new String(channelStatusStruct.PhoneNum));
//                    telRecChannelStatus.setPhoneStatus(PhoneStatusType.values()[convertByteToInt(channelStatusStruct.PhoneStatus)]);
//                    telRecChannelStatus.setRingCount(convertByteToInt(channelStatusStruct.RingCount));
//                    telRecChannelStatus.setPlayBackEnabled(convertByteToInt(channelStatusStruct.PlayBackEnabled) > 0);
                }

                //如果当前通道事件正在被使用 则直接返回
                if(map.contains(phone)){
                    if( channelStatusStruct.PhoneStatus == map.get(phone)){
                        return 0;
                    }
                }
                map.put(phone,convertByteToInt(channelStatusStruct.PhoneStatus));


                // 如果通道名称存在 则通过电话号码获取电话号码关联的人员信息并进行弹屏
                if( channelStatusStruct.PhoneNumLength > 0) {
                    ISysDeptTelService sysDeptTelService = SpringUtils.getBean(ISysDeptTelService.class);
                    IOrRecordService recordService = SpringUtils.getBean(IOrRecordService.class);
                    SysDeptTel sysDeptTel = sysDeptTelService.selectDeptTelByPhoneAndIsScreen(phone.trim());
                    ISysUserService userService = SpringUtils.getBean(ISysUserService.class);
                    System.out.println("响铃次数："+convertByteToInt(channelStatusStruct.RingCount));
                    //来电事件
                    if(map.get(phone) == PhoneStatusType.Ringing.ordinal() && convertByteToInt(channelStatusStruct.RingCount) == 2){
                        //缓存事件状态

                        if (null != sysDeptTel ) {
                            //将信息存放再来电表中
                            OrRecord record = new OrRecord();
                            record.setPhoneCall(callPhone.trim());
                            record.setPhoneAnswer(phone.trim());
                            if(null != sysDeptTel.getUserId()){
                                record.setPhoneMan(sysDeptTel.getUserId().toString());
                            }
                            record.setRemark(sysDeptTel.getDeptId().toString());
                            recordService.insertOrRecord(record);
//
                            System.out.println("呼入号码------------------------："+callPhone.trim());
                            recordMap.put(callPhone.trim(),record.getRecordId());
                            //封装弹屏json
                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put("phone", callPhone.trim());
                            jsonObject.put("recordId", record.getRecordId());
                            jsonObject.put("dataType", "来电弹屏");
                            // 给前端发送弹屏信息
                            if(null != sysDeptTel.getUserId()){
                                WebSocketUsers.sendMessageToUserByText(WebSocketUsers.getUsers().get(sysDeptTel.getUserId().toString()), jsonObject.toJSONString());

                            }
                        }
                    }

                    //呼出事件
                    if(map.get(phone) ==  PhoneStatusType.Outgoing.ordinal()){
                        //将信息存放再来电表中
                        OrRecord record = new OrRecord();
                        record.setPhoneCall(callPhone.trim());
                        record.setPhoneAnswer(phone.trim());
                        if(null != sysDeptTel.getUserId()){
                            record.setPhoneMan(sysDeptTel.getUserId().toString());
                        }
                        record.setTelStatus("2");
                        record.setIsTel("1");
                        recordService.insertOrRecord(record);


                        String uuid = UUID.fastUUID().toString().replaceAll("-","");
                        Calllogtable calllogtable = new Calllogtable();
                        calllogtable.setChan(channel); //通道号
                        calllogtable.setRings(convertByteToInt(channelStatusStruct.RingCount)); //响铃次数
                        calllogtable.setCalltype(1);
                        calllogtable.setSeqid(uuid );
                        calllogtable.setCallerid(callPhone.trim());
                        calllogtable.setStartdate(new Date());
                        calllogtable.setAgentid(sysDeptTel.getDeptId().toString());
                        if(null != sysDeptTel.getUserId()){
                            calllogtable.setUserId(sysDeptTel.getUserId());
                        }
                        calllogtableService.insertCalllogtable(calllogtable);

                        mapUUid.put(callPhone.trim(),uuid);

                        System.out.println("mapUUid:----------------------------"+mapUUid.toString());

                    }

                    //接听事件
                    if(map.get(phone)  == PhoneStatusType.Incoming.ordinal()){

                            //添加接听记录
                            String uuid = UUID.fastUUID().toString().replaceAll("-","");
                            //添加接听记录
                            Calllogtable calllogtable = new Calllogtable();
                            calllogtable.setChan(channel); //通道号
                            calllogtable.setRings(convertByteToInt(channelStatusStruct.RingCount)); //响铃次数
                            calllogtable.setCalltype(0);
                            calllogtable.setSeqid(uuid);
                            calllogtable.setCallerid(callPhone.trim());
                            calllogtable.setAgentid(sysDeptTel.getDeptId().toString());
                            if(null != sysDeptTel.getUserId()){
                                calllogtable.setUserId(sysDeptTel.getUserId());
                            }

                            calllogtable.setDtmf(phone.trim());
                            calllogtable.setStartdate(new Date());
                            //报修科室
                            List<SysDeptTel> deptTel = sysDeptTelService.selectDeptTelByPhone(callPhone.trim());
                            if(deptTel.size() > 0){
                                calllogtable.setVerid(deptTel.get(0).getDeptId());
                            }


                            calllogtableService.insertCalllogtable(calllogtable);
                            System.out.println("呼入号码------------------------："+callPhone.trim());
                            System.out.println("recordMap值---------------------："+recordMap.toString());
                            if(recordMap.containsKey(callPhone.trim())){
                                OrRecord record = new OrRecord();
                                record.setRecordId(recordMap.get(callPhone.trim()));
                                record.setIsTel("1");
                                recordService.updateOrRecord(record);
                            }


                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put("phone",callPhone.trim());
                            jsonObject.put("seqid",uuid);
                            jsonObject.put("dataType","录音记录");

                            mapUUid.put(callPhone.trim(),uuid);
                            //进行
                        if(null != sysDeptTel.getUserId()){
                            WebSocketUsers.sendMessageToUserByText(WebSocketUsers.getUsers().get(sysDeptTel.getUserId().toString()), jsonObject.toJSONString());

                        }
                    }


                    //挂机事件
//                    if(PhoneStatusType.values()[convertByteToInt(channelStatusStruct.PhoneStatus)] == PhoneStatusType.OnHook){
//                        System.out.println("进入挂机事件啦！！！！！！");
//                        System.out.println("mapSize:"+map.size());
//                        if(map.containsKey(phone.trim())){
//                            map.remove(phone.trim());
//                        }
//                    }
                }
                break;
            }
            case ChannelPlayBackChanged:
            case ChannelTalkTimeChanged:
            case ChannelMonitorChanged:

                break;
            case ChannelRecordEnd:
                channel = data.intValue();
                System.out.println("通道ID："+channel);
                //通话录音结束 需要进行下载录音文件;
                CurrentRecordInfoStruct currentRecordInfoStruct = new CurrentRecordInfoStruct();
                TelSDK.instance.TelRecAPI_GetCurrentRecordInfo(EventDevice,channel,currentRecordInfoStruct);

                String filePath = "/RecordFiles/"+String.format("%02d", currentRecordInfoStruct.Year)+""+String.format("%02d", currentRecordInfoStruct.Month)+"/"+String.format("%02d", currentRecordInfoStruct.Day)+"/"+
                     "CH"+String.format("%02d", (channel+1)).replace(" ", "0")+"/"+String.format("%02d", currentRecordInfoStruct.Year)+""+String.format("%02d", currentRecordInfoStruct.Month)+""+String.format("%02d", currentRecordInfoStruct.Day)+""
                        +String.format("%02d", currentRecordInfoStruct.Hour)+""+String.format("%02d", currentRecordInfoStruct.Minutes)+""+String.format("%02d", currentRecordInfoStruct.Seconds)+"-"+"CH"+String.format("%02d", (channel+1))+".wav";
                String fileName = String.format("%02d", currentRecordInfoStruct.Year)+""+String.format("%02d", currentRecordInfoStruct.Month)+""+String.format("%02d", currentRecordInfoStruct.Day)+""
                        +String.format("%02d", currentRecordInfoStruct.Hour)+""+String.format("%02d", currentRecordInfoStruct.Minutes)+""+String.format("%02d", currentRecordInfoStruct.Seconds)+"-"+"CH"+String.format("%02d", (channel+1))+".wav";;
                String path = URLUtils.getPropertis().getProperty("mp3.file.path") + fileName;
                //结束删除map
                if(map.containsKey(phone)){
                    map.remove(phone);
                }
                System.out.println("下载的文件名："+fileName);

                //异步执行下载
                AsyncManager.me().execute(DownloadFactory.download(EventDevice,filePath+"\0",currentRecordInfoStruct,calllogtableService,fileName,path,mapUUid));

//                Thread thread = new Thread() {
//                    @Override
//                    public void run() {
//                        try{
//
//                            //加锁
//                            lock.lock();
//                            //进行判断
//                            download(EventDevice,filePath,currentRecordInfoStruct,calllogtableService,fileName);
//
//                        }catch (Exception e){
//                            e.printStackTrace();
//                        }finally {
//                            //释放锁
//                            lock.unlock();
//                        }
//                    }
//                };
//                thread.start();

                break;
        }

        return 0;
    }


    private static int convertByteToInt(byte data) {
        int heightBit = (int) ((data >> 4) & 0x0F);

        int lowBit = (int) (0x0F & data);

        return heightBit * 16 + lowBit;
    }

}
