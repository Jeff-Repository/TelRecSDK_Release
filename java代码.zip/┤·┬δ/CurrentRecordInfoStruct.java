package com.zgyw.recordbox.struct;

import com.sun.jna.Structure;

import java.util.Arrays;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: MR
 * @Date: 2021/11/16/11:30
 * @Description:
 */
public class CurrentRecordInfoStruct extends Structure {

   public byte Year;
   public byte Month;
   public byte Day;
   public byte Hour;
   public byte Minutes;
   public byte Seconds;
   public Short RecordID;
   public byte RecordType;
   public byte PhoneNumLength;
   public byte [] PhoneNum = new byte[20];



    @Override
    protected List getFieldOrder() {
        return Arrays.asList(new String[] {
                "Year",
                "Month",
                "Day",
                "Hour",
                "Minutes",
                "Seconds",
                "RecordID",
                "RecordType",
                "PhoneNumLength",
                "PhoneNum"
        });
    }

}
