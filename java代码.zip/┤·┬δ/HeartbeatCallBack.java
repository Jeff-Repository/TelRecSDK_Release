package com.zgyw.workorder.service;

import com.sun.jna.Callback;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.IntByReference;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: MR
 * @Date: 2021/11/12/15:18
 * @Description:
 */
public interface HeartbeatCallBack extends Callback {

    /**
     *心跳回调
     */
    public int HeartbeatCallBack(int event, Long EventDevice, Long data, int Length)throws Exception ;
}
