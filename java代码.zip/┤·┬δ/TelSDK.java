package com.zgyw.workorder.service;
import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Callback;
import com.sun.jna.Pointer;
import com.zgyw.common.utils.URLUtils;
import com.zgyw.recordbox.struct.CurrentRecordInfoStruct;

public interface TelSDK extends Library{

    public static TelSDK instance = Native.load(URLUtils.getPropertis().getProperty("tel.sdk.path"), TelSDK.class);

    /**
     * 初始化设备
     * @return
     */
    int TelRecAPI_Init();

    /**
     * 搜索设备
     * @param callback 回调函数
     * @return
     */
    int TelRecAPI_C_SearchDevice(Callback callback);

    /**
     * 获取通道名
     */
    Pointer TelRecAPI_ChannelSetting(Long Device, int Channel);
    /**
     * 退出设备
     * @return
     */
    int TelRecAPI_Exit();
    int TelRecAPI_Logout(Long Device);
    int TelRecAPI_DeleteDevice(Long Device);
    /**
     *创建设备
     */
    Long TelRecAPI_CreateDevice(byte[] DeviceID);

    /*
     * 登录设备
     */
    int TelRecAPI_SetNetAddr(Long Device,byte[] IPaddress,int Port);
    int TelRecAPI_SetUserPassword(Long Device, byte[] UserName, int UserNameLength, byte[] Password);
    int TelRecAPI_Login(Long Device,Boolean RemoteLogin);
    int TelRecAPI_GetChannelSetting(Long Device, int Channel);
    /**
     * 创建心跳
     */
    int TelRecAPI_C_CreateHeartbeatThread(Long Device, Callback CallBack);
    Pointer TelRecAPI_ChannelStatus(Long Device, int Channel);

    int TelRecAPI_DeviceChannels(Long Device);

    int TelRecAPI_GetCurrentRecordInfo(Long Device, int Channel, CurrentRecordInfoStruct currentRecordInfoStruct);

    /**
     * 下载录音文件
     */
    int TelRecAPI_C_DownloadFile(Long Device,byte[] FilePath,Callback CallBack);
}
