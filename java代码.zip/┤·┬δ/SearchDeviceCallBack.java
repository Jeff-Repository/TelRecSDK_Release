package com.zgyw.workorder.service;
import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Callback;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.IntByReference;

public interface SearchDeviceCallBack extends Callback {

  /**
   * 搜索设备回调
   */
  public void SearchDeviceCallBack(int event, long device, Pointer data, int SearchProgress) throws Exception;



}
