package com.zgyw.recordbox.struct;


import com.sun.jna.Pointer;
import com.sun.jna.Structure;

import java.util.Arrays;
import java.util.List;

/**
 * 设备信息
 */
public  class TelRecFoundDeviceStructure extends Structure {

    public TelRecFoundDeviceStructure(Pointer pointer) {
         super(pointer);
         read();
	}
    /**
     * 设备的20位字符唯一ID
     */
    public byte[] DeviceID = new byte[20];

    /**
     * 设备型号字符串
     */
    public String Model;

    /**
     * 设备的电话通道数
     */
    public int Channels;

    /**
     * 设备固件版本，格式为x.x.x.x
     */
    public byte[] Version = new byte[16];

    /**
     * 设备的IP地址，格式为x.x.x.x
     */
    public byte[] IPaddress = new byte[16];

    /**
     * 设备网络端口
     */
    public int NetPort;


//    public static class ByReference extends TelRecFoundDeviceStructure implements Structure.ByReference {}
//    public static class ByValue extends TelRecFoundDeviceStructure implements Structure.ByValue {}
    @Override
    protected List getFieldOrder() {
        return Arrays.asList(new String[] {
                "DeviceID",
                "Model",
                "Channels",
                "Version",
                "IPaddress",
                "NetPort"
        });
    }
}
