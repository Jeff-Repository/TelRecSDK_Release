package com.zgyw.recordbox.enumeration;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: MR
 * @Date: 2021/11/12/16:14
 * @Description:
 */
public enum PhoneStatusType {
    Lost,
    OnHook,
    OffHook,
    Ringing,
    Incoming,
    Outgoing,
    AutoReply,
    VoiceCtrlEnabled,
    VoiceCtrlDisabled,
    PhoneStatusTypeMax,
}
