package com.zgyw.workorder.thread;

import com.sun.jna.Pointer;
import com.zgyw.common.utils.URLUtils;
import com.zgyw.recordbox.enumeration.TelRecEventType;
import com.zgyw.recordbox.struct.CurrentRecordInfoStruct;
import com.zgyw.workorder.domain.Calllogtable;
import com.zgyw.workorder.service.DownloadFileCallBack;
import com.zgyw.workorder.service.ICalllogtableService;
import com.zgyw.workorder.service.TelSDK;
import com.zgyw.workorder.service.impl.HeartbeatCallBackImpl;
import it.sauronsoftware.jave.AudioAttributes;
import it.sauronsoftware.jave.Encoder;
import it.sauronsoftware.jave.EncodingAttributes;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: MR
 * @Date: 2022/03/28/12:05
 * @Description:异步工厂下载录音
 */
public class DownloadFactory {

    /**
     * 进行电话录音文件下载
     * @param EventDevice
     * @param filePath
     * @param currentRecordInfoStruct
     * @param calllogtableService
     * @param fileName
     * @param path
     * @param mapUUid
     * @return
     */
    public static TimerTask download(final Long EventDevice,
                              final String filePath,
                              final CurrentRecordInfoStruct currentRecordInfoStruct ,
                              final ICalllogtableService calllogtableService,
                              final String fileName,
                              final String path,
                              final ConcurrentHashMap<String,String> mapUUid){


        return new TimerTask() {
            @Override
            public void run() {
                try {
                    String phone = new String(currentRecordInfoStruct.PhoneNum,"utf-8").trim().substring(0,currentRecordInfoStruct.PhoneNumLength);


                    DownloadFileCallBack downloadFileCallBack =  new DownloadFileCallBack(){
                        public  int downloadCount = 0, fileSize = 0;
                        public  byte fileBuffer [] = null;
                        public  String map3Paths = "";


                        @Override
                        public  Boolean DownloadFile(int Event, Long EventDevice, Pointer Data, int Length) {

                            System.out.println("------------------------------------字节流"+Length);
                            if(Event == TelRecEventType.GotData.ordinal()){
                                try {
                                    byte[] bytes = new byte[Length];
                                    bytes = Data.getByteArray(0,Length);
                                    System.arraycopy(bytes, 0,fileBuffer, downloadCount, Length);
                                    downloadCount += Length;
                                }catch (Exception e){
                                    e.printStackTrace();
                                }
                            }else if(Event == TelRecEventType.GotDataSize.ordinal()){
                                fileSize = Length;
                                fileBuffer = new byte[fileSize];
                            }
                            if(downloadCount>=fileSize){
                                System.out.println("------------------------开始下载文件------------------------");
                                System.out.println("文件路径path"+path);
                                File file = new File(path);
                                try {
                                    BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(
                                            new FileOutputStream(file),100);
                                    bufferedOutputStream.write(fileBuffer);
                                    bufferedOutputStream.flush();
                                    bufferedOutputStream.close();

                                    //将wav转换为mp3格式
                                    map3Paths = path.substring(0,path.indexOf("."))+".mp3";
                                    System.out.println("map3Path:"+map3Paths);
                                    execute(file,map3Paths);
                                    if(file.delete()){
                                        System.out.println("文件删除成功！");
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                } finally {
                                    downloadCount = 0;
                                    fileSize = 0;
                                    fileBuffer=null;
                                }
                                return false;
                            }else{
                                return false;
                            }
                        }
                    };


                    int i = TelSDK.instance.TelRecAPI_C_DownloadFile(EventDevice, filePath.getBytes(), downloadFileCallBack);
                    System.out.println("返回的状态码："+i);
                    if(i == 20){
                        System.out.println("文件不存在");
                        // path = URLUtils.getPropertis().getProperty("mp3.file.path");
                    }else if(i == 3){
                        System.out.println("连接超时");
                        //path = URLUtils.getPropertis().getProperty("mp3.file.path");
                    }else{
                        System.out.println("phone: "+phone);
                        System.out.println("mapUUid:----------------------------"+mapUUid.toString());
                        if(mapUUid.containsKey(phone)){
                            Calllogtable calllogtable = new Calllogtable();

                            calllogtable.setSeqid(mapUUid.get(phone));
                            calllogtable.setWavefilepath(path.substring(0,path.indexOf("."))+".mp3");
                            calllogtable.setServicePath(fileName.substring(0,fileName.indexOf("."))+".mp3");
                            calllogtableService.updateCalllogtable(calllogtable);
                            //删除数据
                            HeartbeatCallBackImpl.mapUUid.remove(phone);

                            // mp3Path = "";
                        }
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        };
    }



    /**
     * 执行转化过程
     *
     * @param source
     *            源文件
     * @param desFileName
     *            目标文件名
     * @return 转化后的文件
     */
    public static File execute(File source, String desFileName)
            throws Exception {
        File target = new File(desFileName);
        AudioAttributes audio = new AudioAttributes();
        audio.setCodec("libmp3lame");
        audio.setBitRate(new Integer(64000)); //音频比率 MP3默认是1280000
        audio.setChannels(new Integer(1));
        audio.setSamplingRate(new Integer(22050));
        EncodingAttributes attrs = new EncodingAttributes();
        attrs.setFormat("mp3");
        attrs.setAudioAttributes(audio);
        Encoder encoder = new Encoder();
        encoder.encode(source, target, attrs);
        return target;
    }
}
