package com.zgyw.recordbox.enumeration;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: MR
 * @Date: 2021/11/12/15:08
 * @Description:
 */
public enum TelRecErrno {


}
